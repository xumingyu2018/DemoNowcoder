package com.nowcoder.community.dao;

public interface AlphaDao {

    String select();

}
